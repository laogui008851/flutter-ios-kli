import 'dart:async';

FutureOr<void> Function()? onWindowShouldClose;

import 'package:flutter/material.dart';
import 'package:livekit_client/livekit_client.dart';
import 'package:livekit_example/widgets/text_field.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'prejoin.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _sandboxIdCtrl = TextEditingController();
  final _nicknameCtrl = TextEditingController();
  final _roomNameCtrl = TextEditingController();
  bool _busy = false;
  String? _errorMessage;

  // 环境变量配置（编译时注入）
  static const _envSandboxId = String.fromEnvironment('SANDBOX_ID');
  static const _envRoomName = String.fromEnvironment('ROOM_NAME');
  static const _envNickname = String.fromEnvironment('NICKNAME');

  @override
  void initState() {
    super.initState();
    _loadSavedData();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      // 优先使用环境变量，其次使用保存的值
      _sandboxIdCtrl.text = _envSandboxId.isNotEmpty ? _envSandboxId : (prefs.getString('sandboxId') ?? '');
      _nicknameCtrl.text = _envNickname.isNotEmpty ? _envNickname : (prefs.getString('nickname') ?? '');
      _roomNameCtrl.text = _envRoomName.isNotEmpty ? _envRoomName : (prefs.getString('roomName') ?? '');
    });
  }

  @override
  void dispose() {
    _sandboxIdCtrl.dispose();
    _nicknameCtrl.dispose();
    _roomNameCtrl.dispose();
    super.dispose();
  }

  Future<void> _join() async {
    final sandboxId = _sandboxIdCtrl.text.trim();
    final nickname = _nicknameCtrl.text.trim();
    final roomName = _roomNameCtrl.text.trim().isNotEmpty ? _roomNameCtrl.text.trim() : '默认房间';

    // 验证授权码
    if (sandboxId.isEmpty) {
      setState(() {
        _errorMessage = '请输入授权码';
      });
      return;
    }

    setState(() {
      _busy = true;
      _errorMessage = null;
    });

    try {
      // 保存输入内容
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('sandboxId', sandboxId);
      await prefs.setString('nickname', nickname);
      await prefs.setString('roomName', roomName);

      // 使用授权码获取 Token
      final tokenSource = SandboxTokenSource(sandboxId: sandboxId);
      final displayName = nickname.isNotEmpty ? nickname : '用户${DateTime.now().millisecondsSinceEpoch % 10000}';

      final response = await tokenSource.fetch(TokenRequestOptions(
        roomName: roomName,
        participantName: displayName,
        participantIdentity: displayName,
      ));

      if (!mounted) return;

      // 跳转到预览页面，保留登录页以便返回
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PreJoinPage(
            args: JoinArgs(
              url: response.serverUrl,
              token: response.participantToken,
              simulcast: true,
              adaptiveStream: true,
              dynacast: true,
            ),
          ),
        ),
      );
    } catch (e) {
      setState(() {
        _errorMessage = '授权失败: $e';
      });
    } finally {
      setState(() {
        _busy = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
            constraints: const BoxConstraints(maxWidth: 400),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Logo
                Image.asset(
                  'images/removebgpin.png',
                  width: 100,
                  height: 100,
                ),
                const SizedBox(height: 20),
                const Text(
                  '云际会议',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 40),

                // 授权码输入
                LKTextField(
                  label: '授权码',
                  ctrl: _sandboxIdCtrl,
                  hintText: '请输入授权码',
                ),
                const SizedBox(height: 20),

                // 昵称输入
                LKTextField(
                  label: '昵称（可选）',
                  ctrl: _nicknameCtrl,
                  hintText: '显示在房间中的名字',
                ),
                const SizedBox(height: 20),

                // 房间名称输入
                LKTextField(
                  label: '房间名称（可选）',
                  ctrl: _roomNameCtrl,
                  hintText: '默认房间',
                ),
                const SizedBox(height: 10),

                // 错误提示
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(
                        color: Colors.red,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                const SizedBox(height: 30),

                // 加入按钮
                ElevatedButton(
                  onPressed: _busy ? null : _join,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: _busy
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text(
                          '加入房间',
                          style: TextStyle(fontSize: 18),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

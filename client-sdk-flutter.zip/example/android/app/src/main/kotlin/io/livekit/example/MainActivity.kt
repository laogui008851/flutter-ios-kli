package io.livekit.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
